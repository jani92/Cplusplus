#include "Henkilo.h"

Henkilo::Henkilo(int tnro, string nmi)
{
   this->tunnusnro = tnro;
   this->nimi = nmi;
}
