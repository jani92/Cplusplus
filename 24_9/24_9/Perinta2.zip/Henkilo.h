#pragma once

#include <string>

using namespace std;
class Henkilo
{
private:
   int tunnusnro;
public:
   Henkilo(int tnro, string nmi);
protected:
   string nimi;
};

