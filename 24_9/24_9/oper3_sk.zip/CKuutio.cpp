#include "CKuutio.h"

int CKuutio::tilavuus()
{
    return pituus * leveys * korkeus;
}
